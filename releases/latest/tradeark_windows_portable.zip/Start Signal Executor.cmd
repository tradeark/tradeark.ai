@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "BASE_DIR=%~dp0"
set "EXECUTOR=%BASE_DIR%TradeArk.exe"
set "PORT=38182"
set "UI_URL=http://127.0.0.1:%PORT%/"

if not exist "%EXECUTOR%" (
  echo TradeArk.exe was not found in:
  echo %BASE_DIR%
  pause
  exit /b 1
)

call :wait_for_port
if errorlevel 1 (
  pushd "%BASE_DIR%"
  start "" /B TradeArk.exe serve --port %PORT%
  if errorlevel 1 (
    popd
    echo TradeArk could not be started.
    pause
    exit /b 1
  )
  popd
)

for /L %%I in (1,1,20) do (
  call :wait_for_port
  if not errorlevel 1 goto open_ui
  timeout /t 1 /nobreak >nul
)

echo TradeArk did not become ready on %UI_URL%.
echo.
echo Common causes:
echo 1. Windows Security or another antivirus blocked TradeArk.exe.
echo 2. Another program is already using port %PORT%.
echo 3. Windows blocked the downloaded executable on first run.
echo.
echo Try this:
echo - Right-click TradeArk.exe, open Properties, and click Unblock if shown.
echo - Allow TradeArk.exe in Windows Security or your antivirus product.
echo - Run TradeArk.exe manually once to inspect any warning dialog.
pause
exit /b 1

:open_ui
call :detect_public_ip
echo.
echo Local UI: %UI_URL%
if defined PUBLIC_UI_URL (
  echo Remote UI: %PUBLIC_UI_URL%
) else (
  echo Remote UI: auto-detect unavailable. Use this PC's public IP with port %PORT%.
)
start "" "%UI_URL%"
endlocal
exit /b 0

:wait_for_port
where curl.exe >nul 2>&1
if not errorlevel 1 (
  curl.exe --silent --fail http://127.0.0.1:%PORT%/health >nul 2>&1
  if errorlevel 1 exit /b 1
  exit /b 0
)

netstat -ano -p tcp | findstr /R /C:":%PORT% .*LISTENING" >nul 2>&1
if errorlevel 1 exit /b 1
exit /b 0

:detect_public_ip
set "PUBLIC_UI_URL="
set "PUBLIC_IP="
for /f "usebackq delims=" %%I in (`powershell.exe -NoProfile -Command "$ProgressPreference='SilentlyContinue'; $uris=@('https://api64.ipify.org','https://api.ipify.org','https://checkip.amazonaws.com','https://ifconfig.me/ip','https://ipinfo.io/ip'); foreach ($uri in $uris) { try { $content=(Invoke-WebRequest -UseBasicParsing -Uri $uri -TimeoutSec 5).Content; $candidate=($content -replace \"`r\", '').Trim(); $address=$null; if ([System.Net.IPAddress]::TryParse($candidate, [ref]$address)) { $address.IPAddressToString; break } } catch {} }"`) do (
  set "PUBLIC_IP=%%I"
)

if not defined PUBLIC_IP exit /b 0

set "PUBLIC_HOST=%PUBLIC_IP%"
echo %PUBLIC_HOST% | findstr /C:":" >nul 2>&1
if not errorlevel 1 set "PUBLIC_HOST=[%PUBLIC_IP%]"
set "PUBLIC_UI_URL=http://%PUBLIC_HOST%:%PORT%/"
exit /b 0
