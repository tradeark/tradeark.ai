﻿@echo off
taskkill /IM TradeArk.exe /F >nul 2>&1
exit /b 0